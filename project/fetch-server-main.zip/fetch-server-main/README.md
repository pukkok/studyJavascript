npm install
node app.js
